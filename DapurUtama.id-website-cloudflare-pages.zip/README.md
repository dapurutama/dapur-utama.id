# DapurUtama.id — Website

Website company profile static untuk **DapurUtama.id — Spesialis Bawang & Bumbu Dapur**.

## Struktur

```text
.
├── index.html
├── styles.css
├── script.js
├── _headers
├── README.md
└── assets/
    ├── logo.svg
    └── favicon.svg
```

## Deploy ke GitHub + Cloudflare Pages

### 1. GitHub
Buat repository baru, misalnya:

`dapurutama-id`

Upload seluruh isi folder ini ke root repository. Pastikan `index.html` berada di root.

### 2. Cloudflare Pages
Di Cloudflare:
1. Buka **Workers & Pages**
2. Pilih **Create application → Pages → Connect to Git**
3. Pilih repository GitHub `dapurutama-id`
4. Framework preset: **None**
5. Build command: kosong
6. Build output directory: `/`
7. Deploy

Setelah terhubung, setiap push ke branch produksi akan memicu deployment baru.

### 3. Domain
Tambahkan custom domain:

`dapurutama.id`

dan, bila diperlukan:

`www.dapurutama.id`

Cloudflare akan memberi instruksi DNS yang perlu diterapkan.

## Sebelum live

Ganti data contoh berikut di `index.html`:
- `halo@dapurutama.id` dengan email bisnis yang benar.
- Tambahkan nomor WhatsApp bisnis bila sudah tersedia.
- Sesuaikan daftar produk, deskripsi, alamat, dan informasi perusahaan.
- Tambahkan foto produk asli bila sudah tersedia.

## Catatan desain

Palet utama:
- Dark Slate: `#0F172A`
- Chili Red: `#DC2626`
- Deep Red: `#991B1B`
- Emerald Green: `#16A34A`

Website tidak membutuhkan database atau server backend untuk halaman publik ini.
